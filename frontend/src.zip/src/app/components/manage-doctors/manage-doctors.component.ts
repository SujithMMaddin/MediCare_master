import { Component, OnInit, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { DoctorService } from '../../core/services/doctor.service';
import { Doctor } from '../../core/models/doctor.model';
import { extractErrorMessage } from '../../core/services/error-message';

@Component({
  selector: 'app-manage-doctors',
  standalone: true,
  imports: [
    ReactiveFormsModule, MatTableModule, MatCardModule, MatButtonModule, MatIconModule,
    MatFormFieldModule, MatInputModule, MatProgressSpinnerModule, MatSnackBarModule
  ],
  template: `
    <div class="page">
      <div class="page-title">
        <h1>Manage Doctors</h1>
        @if (!formOpen()) {
          <button mat-flat-button color="primary" (click)="openCreate()">
            <mat-icon>add</mat-icon> Add doctor
          </button>
        }
      </div>

      @if (formOpen()) {
        <mat-card class="form-card">
          <mat-card-header>
            <mat-card-title>{{ editingId() ? 'Edit doctor' : 'Add doctor' }}</mat-card-title>
          </mat-card-header>
          <mat-card-content>
            @if (formError()) {
              <div class="error-banner">{{ formError() }}</div>
            }
            <form [formGroup]="form" (ngSubmit)="save()" novalidate>
              <div class="form-row">
                <mat-form-field appearance="outline">
                  <mat-label>Name</mat-label>
                  <input matInput formControlName="name" />
                  @if (form.controls.name.hasError('required')) {
                    <mat-error>Name is required</mat-error>
                  } @else if (form.controls.name.hasError('minlength')) {
                    <mat-error>Name must be at least 2 characters</mat-error>
                  }
                </mat-form-field>

                <mat-form-field appearance="outline">
                  <mat-label>Specialization</mat-label>
                  <input matInput formControlName="specialization" />
                  @if (form.controls.specialization.hasError('required')) {
                    <mat-error>Specialization is required</mat-error>
                  }
                </mat-form-field>

                <mat-form-field appearance="outline">
                  <mat-label>Availability</mat-label>
                  <input matInput formControlName="availability" placeholder="Mon-Fri, 09:00 - 13:00" />
                  @if (form.controls.availability.hasError('required')) {
                    <mat-error>Availability is required</mat-error>
                  }
                </mat-form-field>
              </div>
              <div class="actions">
                <button mat-stroked-button type="button" (click)="closeForm()">Cancel</button>
                <button mat-flat-button color="primary" type="submit" [disabled]="saving()">
                  @if (saving()) { <mat-spinner diameter="20" /> } @else { {{ editingId() ? 'Update' : 'Create' }} }
                </button>
              </div>
            </form>
          </mat-card-content>
        </mat-card>
      }

      @if (loading()) {
        <div class="empty-state"><mat-spinner diameter="40" /></div>
      } @else if (error()) {
        <div class="error-banner">{{ error() }}</div>
      } @else if (doctors().length === 0) {
        <mat-card><mat-card-content class="empty-state">No doctors yet. Add the first one.</mat-card-content></mat-card>
      } @else {
        <mat-card class="table-card">
          <table mat-table [dataSource]="doctors()">
            <ng-container matColumnDef="id">
              <th mat-header-cell *matHeaderCellDef>ID</th>
              <td mat-cell *matCellDef="let d">{{ d.id }}</td>
            </ng-container>
            <ng-container matColumnDef="name">
              <th mat-header-cell *matHeaderCellDef>Name</th>
              <td mat-cell *matCellDef="let d">{{ d.name }}</td>
            </ng-container>
            <ng-container matColumnDef="specialization">
              <th mat-header-cell *matHeaderCellDef>Specialization</th>
              <td mat-cell *matCellDef="let d">{{ d.specialization }}</td>
            </ng-container>
            <ng-container matColumnDef="availability">
              <th mat-header-cell *matHeaderCellDef>Availability</th>
              <td mat-cell *matCellDef="let d">{{ d.availability }}</td>
            </ng-container>
            <ng-container matColumnDef="actions">
              <th mat-header-cell *matHeaderCellDef>Actions</th>
              <td mat-cell *matCellDef="let d">
                <button mat-icon-button color="primary" aria-label="Edit doctor" (click)="openEdit(d)">
                  <mat-icon>edit</mat-icon>
                </button>
                <button mat-icon-button color="warn" aria-label="Delete doctor" (click)="remove(d)">
                  <mat-icon>delete</mat-icon>
                </button>
              </td>
            </ng-container>

            <tr mat-header-row *matHeaderRowDef="columns"></tr>
            <tr mat-row *matRowDef="let row; columns: columns"></tr>
          </table>
        </mat-card>
      }
    </div>
  `,
  styles: [`
    .form-card { margin-bottom: 20px; }
    .actions { display: flex; justify-content: flex-end; gap: 8px; }
  `]
})
export class ManageDoctorsComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly doctorService = inject(DoctorService);
  private readonly snackBar = inject(MatSnackBar);

  readonly columns = ['id', 'name', 'specialization', 'availability', 'actions'];
  readonly doctors = signal<Doctor[]>([]);
  readonly loading = signal(true);
  readonly error = signal<string | null>(null);

  readonly formOpen = signal(false);
  readonly editingId = signal<number | null>(null);
  readonly saving = signal(false);
  readonly formError = signal<string | null>(null);

  readonly form = this.fb.nonNullable.group({
    name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
    specialization: ['', [Validators.required, Validators.maxLength(100)]],
    availability: ['', [Validators.required, Validators.maxLength(255)]]
  });

  ngOnInit(): void {
    this.load();
  }

  openCreate(): void {
    this.editingId.set(null);
    this.form.reset({ name: '', specialization: '', availability: '' });
    this.formError.set(null);
    this.formOpen.set(true);
  }

  openEdit(doctor: Doctor): void {
    this.editingId.set(doctor.id);
    this.form.reset({
      name: doctor.name,
      specialization: doctor.specialization,
      availability: doctor.availability
    });
    this.formError.set(null);
    this.formOpen.set(true);
  }

  closeForm(): void {
    this.formOpen.set(false);
    this.editingId.set(null);
  }

  save(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.saving.set(true);
    this.formError.set(null);

    const payload = this.form.getRawValue();
    const id = this.editingId();
    const request$ = id ? this.doctorService.update(id, payload) : this.doctorService.create(payload);

    request$.subscribe({
      next: () => {
        this.snackBar.open(id ? 'Doctor updated' : 'Doctor added', 'OK', { duration: 3000 });
        this.saving.set(false);
        this.closeForm();
        this.load();
      },
      error: (err) => {
        this.formError.set(extractErrorMessage(err));
        this.saving.set(false);
      }
    });
  }

  remove(doctor: Doctor): void {
    const ok = confirm(
      `Delete ${doctor.name}? All appointments with this doctor will also be removed.`
    );
    if (!ok) {
      return;
    }
    this.doctorService.delete(doctor.id).subscribe({
      next: () => {
        this.snackBar.open('Doctor deleted', 'OK', { duration: 3000 });
        this.load();
      },
      error: (err) => this.snackBar.open(extractErrorMessage(err), 'Close', { duration: 5000 })
    });
  }

  private load(): void {
    this.doctorService.getAll().subscribe({
      next: (list) => {
        this.doctors.set(list);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(extractErrorMessage(err));
        this.loading.set(false);
      }
    });
  }
}

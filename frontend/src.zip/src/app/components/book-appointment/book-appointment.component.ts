import { Component, OnInit, inject, signal } from '@angular/core';
import {
  AbstractControl, FormBuilder, ReactiveFormsModule, ValidationErrors, Validators
} from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { DoctorService } from '../../core/services/doctor.service';
import { AppointmentService } from '../../core/services/appointment.service';
import { Doctor } from '../../core/models/doctor.model';
import { extractErrorMessage } from '../../core/services/error-message';

function futureDate(control: AbstractControl): ValidationErrors | null {
  if (!control.value) {
    return null;
  }
  return new Date(control.value).getTime() > Date.now() ? null : { past: true };
}

@Component({
  selector: 'app-book-appointment',
  standalone: true,
  imports: [
    ReactiveFormsModule, RouterLink, MatCardModule, MatButtonModule, MatIconModule,
    MatFormFieldModule, MatInputModule, MatProgressSpinnerModule, MatSnackBarModule
  ],
  template: `
    <div class="page narrow">
      <a mat-button routerLink="/doctors"><mat-icon>arrow_back</mat-icon> Back to doctors</a>

      @if (loadingDoctor()) {
        <div class="empty-state"><mat-spinner diameter="40" /></div>
      } @else {
        @if (doctor(); as doc) {
          <mat-card>
            <mat-card-header>
              <mat-card-title>Book an appointment</mat-card-title>
              <mat-card-subtitle>{{ doc.name }} · {{ doc.specialization }}</mat-card-subtitle>
            </mat-card-header>
            <mat-card-content>
              <p class="availability"><mat-icon>schedule</mat-icon> Available: {{ doc.availability }}</p>

              @if (error()) {
                <div class="error-banner">{{ error() }}</div>
              }

              <form [formGroup]="form" (ngSubmit)="submit(doc)" novalidate>
                <mat-form-field appearance="outline" class="full-width">
                  <mat-label>Date and time</mat-label>
                  <input matInput type="datetime-local" formControlName="appointmentDate" [min]="minDateTime" />
                  @if (form.controls.appointmentDate.hasError('required')) {
                    <mat-error>Please choose a date and time</mat-error>
                  } @else if (form.controls.appointmentDate.hasError('past')) {
                    <mat-error>Appointment must be in the future</mat-error>
                  }
                </mat-form-field>

                <button mat-flat-button color="primary" type="submit" [disabled]="submitting()">
                  @if (submitting()) { <mat-spinner diameter="20" /> } @else { Confirm booking }
                </button>
              </form>
            </mat-card-content>
          </mat-card>
        } @else if (error()) {
          <div class="error-banner">{{ error() }}</div>
        }
      }
    </div>
  `,
  styles: [`
    .narrow { max-width: 560px; }
    mat-card { margin-top: 12px; }
    .availability { display: flex; align-items: center; gap: 6px; color: var(--mc-muted); }
    .availability mat-icon { font-size: 18px; width: 18px; height: 18px; }
    form { display: flex; flex-direction: column; margin-top: 8px; }
  `]
})
export class BookAppointmentComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly doctorService = inject(DoctorService);
  private readonly appointmentService = inject(AppointmentService);
  private readonly snackBar = inject(MatSnackBar);

  readonly doctor = signal<Doctor | null>(null);
  readonly loadingDoctor = signal(true);
  readonly submitting = signal(false);
  readonly error = signal<string | null>(null);

  /** Lower bound for the datetime-local picker, formatted as yyyy-MM-ddTHH:mm. */
  readonly minDateTime = this.toLocalInput(new Date());

  readonly form = this.fb.nonNullable.group({
    appointmentDate: ['', [Validators.required, futureDate]]
  });

  ngOnInit(): void {
    const doctorId = Number(this.route.snapshot.paramMap.get('doctorId'));
    this.doctorService.getById(doctorId).subscribe({
      next: (doc) => {
        this.doctor.set(doc);
        this.loadingDoctor.set(false);
      },
      error: (err) => {
        this.error.set(extractErrorMessage(err));
        this.loadingDoctor.set(false);
      }
    });
  }

  submit(doc: Doctor): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitting.set(true);
    this.error.set(null);

    this.appointmentService
      .book({ doctorId: doc.id, appointmentDate: this.form.getRawValue().appointmentDate })
      .subscribe({
        next: () => {
          this.snackBar.open('Appointment booked successfully', 'OK', { duration: 3000 });
          this.router.navigate(['/my-appointments']);
        },
        error: (err) => {
          this.error.set(extractErrorMessage(err));
          this.submitting.set(false);
        }
      });
  }

  private toLocalInput(date: Date): string {
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
  }
}

export interface Doctor {
  id: number;
  name: string;
  specialization: string;
  availability: string;
  createdAt: string;
}

export interface DoctorRequest {
  name: string;
  specialization: string;
  availability: string;
}

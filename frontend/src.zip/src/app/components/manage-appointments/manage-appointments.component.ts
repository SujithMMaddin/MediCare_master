import { Component, OnInit, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { AppointmentService } from '../../core/services/appointment.service';
import {
  APPOINTMENT_STATUSES, AppointmentResponse, AppointmentStatus
} from '../../core/models/appointment.model';
import { extractErrorMessage } from '../../core/services/error-message';

@Component({
  selector: 'app-manage-appointments',
  standalone: true,
  imports: [
    DatePipe, MatTableModule, MatCardModule, MatSelectModule, MatFormFieldModule,
    MatProgressSpinnerModule, MatSnackBarModule
  ],
  template: `
    <div class="page">
      <div class="page-title">
        <h1>Manage Appointments</h1>
      </div>

      @if (loading()) {
        <div class="empty-state"><mat-spinner diameter="40" /></div>
      } @else if (error()) {
        <div class="error-banner">{{ error() }}</div>
      } @else if (appointments().length === 0) {
        <mat-card><mat-card-content class="empty-state">No appointments have been booked yet.</mat-card-content></mat-card>
      } @else {
        <mat-card class="table-card">
          <table mat-table [dataSource]="appointments()">
            <ng-container matColumnDef="id">
              <th mat-header-cell *matHeaderCellDef>ID</th>
              <td mat-cell *matCellDef="let a">{{ a.id }}</td>
            </ng-container>
            <ng-container matColumnDef="patient">
              <th mat-header-cell *matHeaderCellDef>Patient</th>
              <td mat-cell *matCellDef="let a">
                <div>{{ a.userName }}</div>
                <small class="muted">{{ a.userEmail }}</small>
              </td>
            </ng-container>
            <ng-container matColumnDef="doctor">
              <th mat-header-cell *matHeaderCellDef>Doctor</th>
              <td mat-cell *matCellDef="let a">
                <div>{{ a.doctorName }}</div>
                <small class="muted">{{ a.doctorSpecialization }}</small>
              </td>
            </ng-container>
            <ng-container matColumnDef="date">
              <th mat-header-cell *matHeaderCellDef>Date &amp; time</th>
              <td mat-cell *matCellDef="let a">{{ a.appointmentDate | date: 'EEE, d MMM y, h:mm a' }}</td>
            </ng-container>
            <ng-container matColumnDef="status">
              <th mat-header-cell *matHeaderCellDef>Status</th>
              <td mat-cell *matCellDef="let a"><span class="status-chip" [class]="a.status">{{ a.status }}</span></td>
            </ng-container>
            <ng-container matColumnDef="update">
              <th mat-header-cell *matHeaderCellDef>Update status</th>
              <td mat-cell *matCellDef="let a">
                <mat-form-field appearance="outline" subscriptSizing="dynamic" class="status-select">
                  <mat-select [value]="a.status" [disabled]="a.status === 'CANCELLED' || busyId() === a.id"
                              (selectionChange)="changeStatus(a, $event.value)" aria-label="Appointment status">
                    @for (s of statuses; track s) {
                      <mat-option [value]="s">{{ s }}</mat-option>
                    }
                  </mat-select>
                </mat-form-field>
              </td>
            </ng-container>

            <tr mat-header-row *matHeaderRowDef="columns"></tr>
            <tr mat-row *matRowDef="let row; columns: columns"></tr>
          </table>
        </mat-card>
      }
    </div>
  `,
  styles: [`
    .muted { color: var(--mc-muted); }
    .status-select { width: 160px; margin: 6px 0; }
  `]
})
export class ManageAppointmentsComponent implements OnInit {
  private readonly appointmentService = inject(AppointmentService);
  private readonly snackBar = inject(MatSnackBar);

  readonly columns = ['id', 'patient', 'doctor', 'date', 'status', 'update'];
  readonly statuses = APPOINTMENT_STATUSES;
  readonly appointments = signal<AppointmentResponse[]>([]);
  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly busyId = signal<number | null>(null);

  ngOnInit(): void {
    this.load();
  }

  changeStatus(appt: AppointmentResponse, status: AppointmentStatus): void {
    if (status === appt.status) {
      return;
    }
    this.busyId.set(appt.id);
    this.appointmentService.updateStatus(appt.id, status).subscribe({
      next: (updated) => {
        this.appointments.update((list) => list.map((a) => (a.id === updated.id ? updated : a)));
        this.snackBar.open(`Appointment #${updated.id} marked ${updated.status}`, 'OK', { duration: 3000 });
        this.busyId.set(null);
      },
      error: (err) => {
        this.snackBar.open(extractErrorMessage(err), 'Close', { duration: 5000 });
        // Re-render the row so the select snaps back to the real status.
        this.appointments.update((list) => [...list]);
        this.busyId.set(null);
      }
    });
  }

  private load(): void {
    this.appointmentService.getAll().subscribe({
      next: (list) => {
        this.appointments.set(list);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(extractErrorMessage(err));
        this.loading.set(false);
      }
    });
  }
}

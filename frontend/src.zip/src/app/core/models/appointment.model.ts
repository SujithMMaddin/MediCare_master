export type AppointmentStatus = 'BOOKED' | 'COMPLETED' | 'CANCELLED';

export const APPOINTMENT_STATUSES: AppointmentStatus[] = ['BOOKED', 'COMPLETED', 'CANCELLED'];

export interface AppointmentRequest {
  doctorId: number;
  /** ISO local date-time, e.g. 2026-10-20T10:30 */
  appointmentDate: string;
}

export interface AppointmentResponse {
  id: number;
  appointmentDate: string;
  status: AppointmentStatus;
  userId: number;
  userName: string;
  userEmail: string;
  doctorId: number;
  doctorName: string;
  doctorSpecialization: string;
  createdAt: string;
}
